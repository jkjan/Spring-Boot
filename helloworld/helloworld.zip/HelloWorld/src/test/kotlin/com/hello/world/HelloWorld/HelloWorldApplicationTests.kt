package com.hello.world.HelloWorld

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class HelloWorldApplicationTests {

	@Test
	fun contextLoads() {
	}

}
